#!/bin/bash
set -u
PORT=13155
echo "Stopping synth-loop (port $PORT)..."

pids=""
if command -v lsof >/dev/null 2>&1; then
    pids=$(lsof -ti tcp:$PORT 2>/dev/null || true)
fi
if [ -z "$pids" ] && command -v ss >/dev/null 2>&1; then
    pids=$(ss -ltnp 2>/dev/null | grep -E ":$PORT\\b" | grep -oP 'pid=\\K[0-9]+' | sort -u)
fi
if [ -z "$pids" ] && command -v fuser >/dev/null 2>&1; then
    pids=$(fuser $PORT/tcp 2>/dev/null | tr -s ' ' || true)
fi

if [ -z "$pids" ]; then
    echo "  no process listening on $PORT"
    exit 0
fi

echo "  found PID(s): $pids"
for pid in $pids; do
    kill -TERM "$pid" 2>/dev/null && echo "  sent TERM to $pid"
done
sleep 2
for pid in $pids; do
    if kill -0 "$pid" 2>/dev/null; then
        kill -9 "$pid" 2>/dev/null && echo "  force killed $pid"
    fi
done
echo "Done."
