#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/sl-py"
echo "[INFO] installing dependencies..."
pip install -r requirements.txt --quiet

echo "[OK] starting synth-loop v0.1.2"
echo "     configure API keys / endpoints in config.yaml"
python3 -m app.main
