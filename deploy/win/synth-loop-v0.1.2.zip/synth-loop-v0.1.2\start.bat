@echo off
chcp 65001 >nul
title synth-loop v0.1.2

cd /d "%~dp0sl-py"
echo [INFO] installing dependencies...
pip install -r requirements.txt --quiet

echo [OK] starting synth-loop v0.1.2
echo      configure API keys / endpoints in config.yaml
python -m app.main

pause
