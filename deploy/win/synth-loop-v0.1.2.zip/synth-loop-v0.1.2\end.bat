@echo off
chcp 65001 >nul
title synth-loop stop

echo Stopping synth-loop (port 13155)...
for /f "tokens=5" %%a in ('netstat -ano ^| findstr :13155 ^| findstr LISTENING') do (
    taskkill /PID %%a /F >nul 2>&1
    if not errorlevel 1 echo   stopped PID %%a
)
echo Done.
pause
